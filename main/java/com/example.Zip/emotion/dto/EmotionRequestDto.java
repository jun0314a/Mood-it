package com.example.emotion.dto;

import lombok.Data;

@Data
public class EmotionRequestDto {
    private String text;
}
