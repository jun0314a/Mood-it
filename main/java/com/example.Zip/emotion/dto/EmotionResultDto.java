package com.example.emotion.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmotionResultDto {
    private String emotion;
}
