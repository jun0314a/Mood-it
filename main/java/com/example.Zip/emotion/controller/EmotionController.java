package com.example.emotion.controller;

import com.example.emotion.dto.EmotionRequestDto;
import com.example.emotion.dto.EmotionResultDto;
import com.example.emotion.service.EmotionService;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/emotion")
@RequiredArgsConstructor
public class EmotionController {

    private final EmotionService emotionService;

    @PostMapping("/analyze")
    public ResponseEntity<EmotionResultDto> analyzeEmotion(@RequestBody EmotionRequestDto requestDto) {
        EmotionResultDto result = emotionService.analyzeEmotion(requestDto.getText());
        return ResponseEntity.ok(result);
    }
}
